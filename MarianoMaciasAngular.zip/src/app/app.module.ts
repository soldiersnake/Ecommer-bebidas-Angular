import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';


import { FormsModule, ReactiveFormsModule} from '@angular/forms';  //esto se importa para poder usar formularios en angular
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { DetalleProductoComponent } from './pages/detalle-producto/detalle-producto.component';
import { CatalogoComponent } from './pages/catalogo/catalogo.component';
import { RegistroComponent } from './registro/registro.component';
import { MenuComponent } from './menu/menu.component'; //import de two way(para formularios)
import { HttpClientModule } from '@angular/common/http';
import { EjemplosComponent } from './ejemplos/ejemplos.component';
import { ProductosAltaComponent } from './pages/productos-alta/productos-alta.component';
import { Producto2Component } from './components/producto2/producto2.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button'; //Este es el import de button de angularMaterial
import {MatMenuModule} from '@angular/material/menu';
import {MatCardModule} from '@angular/material/card';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatTableModule} from '@angular/material/table';
import { ListadoprodComponent } from './pages/listadoprod/listadoprod.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { ProductoseditarComponent } from './pages/productoseditar/productoseditar.component';
import { CategoriasaltaComponent } from './pages/categorias/categoriasalta/categoriasalta.component';
import { CategoriaslistadoComponent } from './pages/categorias/categoriaslistado/categoriaslistado.component';
import { CategoriaseditarComponent } from './pages/categorias/categoriaseditar/categoriaseditar.component';
import { FileuploadComponent } from './pages/fileupload/fileupload.component';

import {FileUploadModule} from 'ng2-file-upload';
import { QuienessomosComponent } from './pages/quienessomos/quienessomos.component';



@NgModule({
  declarations: [   //aca declaro los componentes
    AppComponent,
    HomeComponent,
    LoginComponent,
    DetalleProductoComponent,
    CatalogoComponent,
    RegistroComponent,
    MenuComponent,
    EjemplosComponent,
    ProductosAltaComponent,
    Producto2Component,
    ListadoprodComponent,
    ProductoseditarComponent,
    CategoriasaltaComponent,
    CategoriaslistadoComponent,
    CategoriaseditarComponent,
    FileuploadComponent,
    QuienessomosComponent,
    

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule, //incluir esto genera q podamos hacer consultas tipo postaman desde angular
    ReactiveFormsModule, //incluimos para two way(eldoble blindeo)
    FormsModule, BrowserAnimationsModule, //incluimos para two way(eldoble blindeo)
    MatButtonModule,  //incluimos el button de angularMaterial aca tambien
    MatMenuModule,
    MatCardModule,
    MatGridListModule,
    MatInputModule,
    MatSelectModule,
    MatSnackBarModule,
    MatPaginatorModule,
    NgbModule,
    NgxPaginationModule,
    NgxDatatableModule,
    FileUploadModule,
    MatTableModule,


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
