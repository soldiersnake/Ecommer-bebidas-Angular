import { Component, OnInit,Input } from '@angular/core';
import { ComprasService } from '../../services/compras.service';
import { ProductosService } from 'src/app/services/productos.service';
import { AutenticacionService } from 'src/app/services/autenticacion.service';
import { id } from '@swimlane/ngx-datatable';
import { CategoriasService } from 'src/app/services/categorias.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-producto2',
  templateUrl: './producto2.component.html',
  styleUrls: ['./producto2.component.css']
})
export class Producto2Component implements OnInit {

  @Input() data={ //puede llamarse data o cualquier nombre, y en este caso recibe la info de items q es la variable productos
    _id:'',
    name:'',
    precio:'',
    descripcion:'',
}  

  id=<any>[];
  productos=<any>[];
  categorias=<any>[];


  constructor(private compr:ComprasService, private product:ProductosService, private cliente:AutenticacionService, private catego:CategoriasService, private route:ActivatedRoute) {
    
    //chequear
    this.id = this.route.snapshot.paramMap.get("id")
    this.product.getByid(id).subscribe(data=>{

      this.productos=data;
      console.log("productos",this.productos)
     },err=>{console.log(err)})


   }
   
  //viene por aca
   comprar(id){
    console.log(id)
    this.compr.compra(id)
  }

  ngOnInit(): void {
  }

}
