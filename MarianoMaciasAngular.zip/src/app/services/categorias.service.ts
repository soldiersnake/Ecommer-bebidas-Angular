import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CategoriasService {

  constructor(private http:HttpClient) { }
  

  getCategorias(pageInfo=null){
    let query='';
    if(pageInfo){
      query='?page='+(pageInfo["offset"]+1)
    }
    return this.http.get('http://localhost:3000/categorias/'+ query)
  }

  getCategoriasSinPaginado(){
    return this.http.get('http://localhost:3000/categorias/combo/')
  }

  save(datos){  //generacion del metodo save para generar el post en express
    return this.http.post("http://localhost:3000/categorias",datos)  //con "datos" estamos aclarando q enviamos los datos
   }
  
   getByid(id){
     return this.http.get('http://localhost:3000/categorias/'+id)
   }
 
   delete(id){
     return this.http.delete('http://localhost:3000/categorias/'+id)
   }
 
   update(id,datos){
     return this.http.put('http://localhost:3000/categorias/'+id,datos)
 
   }
 
}
