//productos.service esta importando la info de express que consulta a la BD para exportarla al componente q nosotros querramos 
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  constructor(private http:HttpClient) { }
  getProductos(pageInfo=null){  //metodo get q hace peticion a express
    let query='';
    if(pageInfo){
      query='?page='+(pageInfo["offset"]+1)
    }

   return this.http.get("http://localhost:3000/productos/"+query,{
     headers:{  //el header en el caso get lo ponemos en el segundo parametro para almacenar el token
       'x-access-token':localStorage.getItem('token')
     }
   }) //estamos haciendo una peticion del tipo GET bajo el servicio de "http" entre "La URL a la cual quiero llamar"
  }

  save(datos){  //generacion del metodo save para generar el post en express
   return this.http.post("http://localhost:3000/productos/",datos)  //con "datos" estamos aclarando q enviamos los datos
  }

  getCategorias(){
    return this.http.get('http://localhost:3000/categorias')
  }

  getByid(id){
    return this.http.get('http://localhost:3000/productos/'+id)
  }

  delete(id){
    return this.http.delete('http://localhost:3000/productos/'+id)
  }

  update(id,datos){
    return this.http.put('http://localhost:3000/productos/'+id,datos)

  }
}
