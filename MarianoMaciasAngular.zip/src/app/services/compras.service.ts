import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ComprasService {

  constructor(private http:HttpClient) {   }


  getCompra(){
    return this.http.get('http://localhost:3000/ventas'),{
      headers:{ 
        'x-access-token':localStorage.getItem('token')
      }}
  }


  compra(datos){
    return this.http.post('http://localhost:3000/ventas',datos),{
    headers:{  
      'x-access-token':localStorage.getItem('token')
    }}
  }


}
