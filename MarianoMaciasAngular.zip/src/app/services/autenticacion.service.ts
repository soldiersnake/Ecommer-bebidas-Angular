import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; //1º importamos el httpCLiente par implementar servicios
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AutenticacionService {

  //instanciamos el BehaviouSubject
  //false es el usuario no esta logueado y el true q si lo esta
  authenticationState = new BehaviorSubject(false);

  constructor(private http:HttpClient) { //2º inyectamos httpClient en el contructor

    if(localStorage.getItem('token')){ //para cuando recargo la pagina siga logueado, hasta cerrar sesion
      this.authenticationState.next(true)
    }

  }

  login(datos){  //generamos el metodo login()
    return this.http.post("http://localhost:3000/usuarios/login",datos)
  }
  
  registro(datos){  //generacion del metodo save para generar el post en express
    return this.http.post("http://localhost:3000/usuarios/registro",datos)  //con "datos" estamos aclarando q enviamos los datos
  }// EN REALIDAD EL POST DE REGISTRO YA LO TENGO EN OTRO SERVICIO


  logout(){
    localStorage.removeItem('token')
    this.authenticationState.next(false)
  }

  authenticate(){ //aca cambiamos la autenticacion a TRUE
    this.authenticationState.next(true)
  }

  isAuthenticate(){ //aca retornamos el estado del LOGIN
    return this.authenticationState
  }
}
