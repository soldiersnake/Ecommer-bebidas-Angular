//aca definimos el ruteo, las diferente URL (rutas)

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent }from './home/home.component';  //aca hago los import de los componentes
import { LoginComponent } from './login/login.component';
import { DetalleProductoComponent } from './pages/detalle-producto/detalle-producto.component';
import { CatalogoComponent } from './pages/catalogo/catalogo.component';
import { RegistroComponent } from './registro/registro.component';
import { MenuComponent } from './menu/menu.component';
import { EjemplosComponent } from './ejemplos/ejemplos.component';
import { ProductosAltaComponent } from './pages/productos-alta/productos-alta.component';
import { Producto2Component } from './components/producto2/producto2.component';
import { ListadoprodComponent } from './pages/listadoprod/listadoprod.component';
import { ProductoseditarComponent } from './pages/productoseditar/productoseditar.component';
import { CategoriasaltaComponent } from './pages/categorias/categoriasalta/categoriasalta.component';
import { CategoriaslistadoComponent } from './pages/categorias/categoriaslistado/categoriaslistado.component';
import { CategoriaseditarComponent } from './pages/categorias/categoriaseditar/categoriaseditar.component';
import { AuthGuard } from './auth.guard';
import { QuienessomosComponent } from './pages/quienessomos/quienessomos.component';




const routes: Routes = [
  {path:"", component:HomeComponent},  //aca hago el ruteo de los componentes
  {path:"login", component:LoginComponent},
  {path:"productos/:id", component:DetalleProductoComponent},
  {path:"catalogo", component:CatalogoComponent},
  {path:"registro", component:RegistroComponent},
  {path:"menu", component:MenuComponent},
  {path:"ejemplos", component:EjemplosComponent},
  {path:"productos-alta", canActivate:[AuthGuard], component:ProductosAltaComponent},
  {path:"productos", component:Producto2Component},
  {path:"listado", component:ListadoprodComponent},
  {path:"editar/:id", component:ProductoseditarComponent},
  {path:"altacatego", canActivate:[AuthGuard], component:CategoriasaltaComponent},
  {path:"listacatego", component:CategoriaslistadoComponent},
  {path:"editcatego/:id", component:CategoriaseditarComponent},
  {path:"quienes-somos", component:QuienessomosComponent},



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
