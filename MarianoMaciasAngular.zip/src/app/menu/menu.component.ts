import { Component, OnInit } from '@angular/core';
import { AutenticacionService } from '../services/autenticacion.service';
import { state } from '@angular/animations';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  opciones=[
    {path:"/",name:"home"},
    {path:"/login",name:"login"},
    {path:"/registro",name:"registro"},
    {path:"/quienes-somos",name:"Quienes somos"},
  ];
 opciones2=[
    {path:"/catalogo",name:"catalogo"},
    {path:"/productos-alta",name:"Alta productos"},
    {path:"listado", name:"Listado productos"},
  ];
  opciones3=[
    {path:"/listacatego",name:"Listado Categorias"},
    {path:"/altacatego",name:"Alta categoria"},
    {path:"editcatego/:id", name:"Modificar Categoria"},
  ];
  isLogin;

  constructor(private auth:AutenticacionService) { 

    this.auth.isAuthenticate().subscribe((state)=>{ //Estamos editando el menu, dependiento del estado de autenticacion
      
      this.isLogin=state;
      if(state){   //SI estamos autenticado, mostramos estas opciones de menu
        this.opciones=[
          {path:"/",name:"Home"},
        ];
        this.opciones2=[
          {path:"/catalogo",name:"catalogo"},
          {path:"/productos-alta",name:"Alta productos"},
          {path:"listado", name:"Listado productos"},
        ];
        this.opciones3=[
          {path:"/listacatego",name:"Listado Categorias"},
          {path:"/altacatego",name:"Alta categoria"},
          {path:"editcatego/:id", name:"Modificar Categoria"},
        ];
      }else{ //SINO, mostramos estas otras
        this.opciones=[
          {path:"/",name:"Home"},
          {path:"/login",name:"Login"},
          {path:"/registro",name:"Registro"},
        ];
        this.opciones2=[
          {path:"/catalogo",name:"Catalogo"},
          {path:"listado", name:"Listado productos"},
        ];
        this.opciones3=[
          {path:"/listacatego",name:"Listado Categorias"},
        ];
      
      }
    })
  }
  logOut(){
    this.auth.logout()
  }

  ngOnInit(): void {
  }

}
