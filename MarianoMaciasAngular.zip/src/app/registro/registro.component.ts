import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms'; //para los formularios hacemos los import de formbuilder y validators
import { Router } from '@angular/router';
import { AutenticacionService} from '../services/autenticacion.service' ;

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {

  myform:FormGroup;
  
  constructor(private formularioRegistro:FormBuilder, private regis:AutenticacionService, private route:Router) {  //citamos el formbuilder para q funcione formulario y la llamamos como querramos
    this.myform = this.formularioRegistro.group({  //declaramos el json del formulario
      nombre:["", Validators.required],   //aca requiero la validacion
      apellido:["", Validators.required],
      usuario:["", [Validators.required,Validators.minLength(4)]], //aca hago array del validato para q con un minLegth requiero q halla mas de 4 caracteres
      email:["", Validators.required],
      password:["", [Validators.required,Validators.minLength(6)]], //aca hago array del validato para q con un minLegth requiero q halla mas de 6 caracteres
    })
  }
  registro(){ // generamos el metodo save para guardar el formulario q lo sitamos en el .html con (ngSubmit)
    console.log(this.myform.value)
    this.regis.registro(this.myform.value).subscribe(data=>{
      console.log(data)
      this.route.navigate(['/login'])   //aca declaramos en el contructor la variable route en private, para una vez creado el usuario rederigir a login
    },err=>{      //aca aplicamos el mensaje de error, derivaro del tray and cacht en express
      alert(err.error.msg);
      alert("El usuario ya existe!");
    })
  } //NO SE XQ NO ME TIRAR EL CARTEL DE ALERTA


  ngOnInit(): void {
  }

}
