import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms'; //para los formularios hacemos los import de formbuilder y validators
import { AutenticacionService} from '../services/autenticacion.service' ;
import { Router } from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar'; //el import del snack bar

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  myform:FormGroup;


  constructor(private formularioRegistro:FormBuilder, private auth:AutenticacionService,
    private router: Router, private _snackBar: MatSnackBar) { //hacemos el import de autenticationService para q funcione el metodo con el servicio
    this.myform = this.formularioRegistro.group({  //declaramos el json del formulario
      usuario:["", [Validators.required,Validators.minLength(4)]], //aca hago array del validato para q con un minLegth requiero q halla mas de 4 caracteres
      password:["", [Validators.required,Validators.minLength(6)]], //aca hago array del validato para q con un minLegth requiero q halla mas de 6 caracteres
    })

  }
  login(){
    console.log(this.myform.value)
    this.auth.login(this.myform.value).subscribe(data=>{
      console.log(data)
      localStorage.setItem('token',data["token"])   //para gaurdar el token del login
      this.auth.authenticate();
      this._snackBar.open('Bienvenidos/as', 'cerrar', {
        duration: 2000,
      });

      this.router.navigate(['/']) //metodo para rederigir, en este caso el token
    })
  }

  ngOnInit(): void {
  }

}
