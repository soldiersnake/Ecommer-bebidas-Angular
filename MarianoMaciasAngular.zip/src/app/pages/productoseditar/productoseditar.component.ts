import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms'; //1º para los formularios hacemos los import de formbuilder, validators y formGroup
import { ProductosService } from '../../services/productos.service';
import { ActivatedRoute } from '@angular/router';
import { CategoriasService } from '../../services/categorias.service';


@Component({
  selector: 'app-productoseditar',
  templateUrl: './productoseditar.component.html',
  styleUrls: ['./productoseditar.component.css']
})
export class ProductoseditarComponent implements OnInit {

  id;
  myform:FormGroup;  //3º luego declaramos la variable de clase myform q responde a formGroup
  categorias=<any>[];

  constructor(private fb:FormBuilder, private prod:ProductosService, private route:ActivatedRoute, private catego:CategoriasService) { //2ºinyectamos en el contructor la dependencia de formbuilder alojandola en la variable fb / ingresamos productosServices para poder realizar el POST
    
    this.id = this.route.snapshot.paramMap.get("id")
    this.catego.getCategoriasSinPaginado().subscribe(data=>{

      this.categorias=data;
      console.log("categorias",this.categorias)
     },err=>{console.log(err)})


    this.billFormController()
    this.prod.getByid(this.id).subscribe(data=>{
      console.log(data)
      this.myform = this.fb.group({ //4º paso delaramos myform es igual a fb.group
        name:[data["name"],Validators.required],   //5º asignamos estructura de formulario
        precio:[data["precio"],Validators.required],
        marca:[data["marca"],Validators.required],
        descripcion:[data["descripcion"],],
        sku:[data["sku"],Validators.required],
        cantidad:[data["cantidad"],Validators.required],
        categoria:[data["categoria"],Validators.required],  
       })
  
    })

  }
  billFormController(data=null){
    this.myform = this.fb.group({ //4º paso delaramos myform es igual a fb.group
      name:["",Validators.required],   //5º asignamos estructura de formulario
      precio:["",Validators.required],
      marca:["",Validators.required],
      descripcion:["",],
      sku:["",Validators.required],
      cantidad:["",Validators.required],
      categoria:["",Validators.required],  
     })

  }
  save(){ // generamos el metodo save para guardar el formulario q lo sitamos en el .html con (ngSubmit)
    console.log(this.myform.value)
    this.prod.update(this.id,this.myform.value).subscribe(data=>{
      console.log(data)
    })
  }

  ngOnInit(): void {
  }

}
