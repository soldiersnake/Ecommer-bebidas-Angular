import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductoseditarComponent } from './productoseditar.component';

describe('ProductoseditarComponent', () => {
  let component: ProductoseditarComponent;
  let fixture: ComponentFixture<ProductoseditarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductoseditarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductoseditarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
