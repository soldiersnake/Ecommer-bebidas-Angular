import { Component, OnInit } from '@angular/core';
import { ProductosService } from '../../services/productos.service';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent implements OnInit {


  productos:[];   //productos, almacena la data venida de express, luego esta misma variable productos la usamos en el input

  constructor(private prod:ProductosService) { 

    this.prod.getProductos().subscribe(data=>{ //data=> aplica la funcion de callBack
      console.log(data);
      this.productos=data["docs"];  //aca asigno al array productos la documentacion de "data", para luego llamar en el .html 

    })

  }

  ngOnInit(): void {
  }

}
