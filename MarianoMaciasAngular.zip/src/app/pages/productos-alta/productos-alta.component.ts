
import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms'; //1º para los formularios hacemos los import de formbuilder, validators y formGroup
import { ProductosService } from '../../services/productos.service';
import { CategoriasService } from 'src/app/services/categorias.service';
import { FileUploader } from 'ng2-file-upload';
import { Router } from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar'; //el import del snack bar



const URL = 'http://localhost:3000/productos/upload';

@Component({
  selector: 'app-productos-alta',
  templateUrl: './productos-alta.component.html',
  styleUrls: ['./productos-alta.component.css']
})
export class ProductosAltaComponent implements OnInit {

  public uploader:FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});

  myform:FormGroup;  //3º luego declaramos la variable de clase myform q responde a formGroup
  categorias=<any>[]
  images:Array<any>=[];

  constructor(private fb:FormBuilder, private prod:ProductosService,
    private catego:CategoriasService, private route:Router, private _snackBar: MatSnackBar) { //2ºinyectamos en el contructor la dependencia de formbuilder alojandola en la variable fb / ingresamos productosServices para poder realizar el POST
    this.myform = this.fb.group({ //4º paso delaramos myform es igual a fb.group
    name:["",Validators.required],   //5º asignamos estructura de formulario
    precio:["",Validators.required],
    marca:["",Validators.required],
    descripcion:["",],
    sku:["",Validators.required],
    cantidad:["",Validators.required],
    categoria:["",Validators.required],
    images:["",],
   })
   this.catego.getCategoriasSinPaginado().subscribe(data=>{

    this.categorias=data;
    console.log("categorias",this.categorias)
   },err=>{console.log(err)})
  }

  save(){
    this.uploader.uploadAll();
    console.log(this.myform.value)
    this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
      console.log("ImageUpload:uploaded:", item, status, response);
      let json =  JSON.parse(response);
      console.log("json data",json["data"])
      this.myform.get('images').setValue(json["data"])
      this.prod.save(this.myform.value).subscribe(data=>{
        console.log(data)
        this.route.navigate(['/listado'])
        this._snackBar.open('El producto fue dado de alta', 'cerrar', {
          duration: 2000,
        });
      })
    };
  }

  /*save(){ // generamos el metodo save para guardar el formulario q lo sitamos en el .html con (ngSubmit)
    this.uploader.uploadAll();
    console.log(this.myform.value)
    this.prod.save(this.myform.value).subscribe(data=>{
      console.log(data)
      this.route.navigate(['/listado'])   //aca declaramos en el contructor la variable route en private, para una vez creado el usuario rederigir a listado
      this._snackBar.open('El producto fue dado de alta', 'cerrar', {
        duration: 2000,
      });
    })
  }*/

  ngOnInit(): void {

    //override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
    this.uploader.onAfterAddingFile = (file)=> { file.withCredentials = false; };
    //overide the onCompleteItem property of the uploader so we are 
    //able to deal with the server response.
    this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
         console.log("ImageUpload:uploaded:", item, status, response);
         let json = JSON.parse(response);
         console.log(json["data"])
         this.myform.get('images').setValue(json["data"])
     };

  }

}


