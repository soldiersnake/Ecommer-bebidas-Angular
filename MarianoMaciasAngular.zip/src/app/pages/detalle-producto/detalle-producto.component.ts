import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductosService } from '../../services/productos.service';

@Component({
  selector: 'app-detalle-producto',
  templateUrl: './detalle-producto.component.html',
  styleUrls: ['./detalle-producto.component.css']
})
export class DetalleProductoComponent implements OnInit {

  producto;

  constructor(private activeRouter:ActivatedRoute, private prod:ProductosService) {  //private es para ingresar solo del back para que el usuario no vea
    
    
    let id = this.activeRouter.snapshot.paramMap.get("id")  //para acceder a la URL mapeada desde la ruta detallesProductos/:id
    
    this.prod.getByid(id).subscribe(data=>{
      console.log(data)
      this.producto=data;
    })
   }

  ngOnInit(): void {
  }

}
