import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoriasaltaComponent } from './categoriasalta.component';

describe('CategoriasaltaComponent', () => {
  let component: CategoriasaltaComponent;
  let fixture: ComponentFixture<CategoriasaltaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategoriasaltaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoriasaltaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
