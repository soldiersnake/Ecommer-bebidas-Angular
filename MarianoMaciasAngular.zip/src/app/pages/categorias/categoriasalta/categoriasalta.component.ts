import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms';
import { CategoriasService } from 'src/app/services/categorias.service';
import { Router } from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar'; //el import del snack bar


@Component({
  selector: 'app-categoriasalta',
  templateUrl: './categoriasalta.component.html',
  styleUrls: ['./categoriasalta.component.css']
})
export class CategoriasaltaComponent implements OnInit {

  myform:FormGroup;  //3º luego declaramos la variable de clase myform q responde a formGroup

  constructor(private fb:FormBuilder, private catego:CategoriasService,
    private route:Router, private _snackBar:MatSnackBar) { //2ºinyectamos en el contructor la dependencia de formbuilder alojandola en la variable fb / ingresamos productosServices para poder realizar el POST
    
      this.myform = this.fb.group({ //4º paso delaramos myform es igual a fb.group
    nombre:["",Validators.required],   //5º asignamos estructura de formulario
   })
  }
  save(){ // generamos el metodo save para guardar el formulario q lo sitamos en el .html con (ngSubmit)
    console.log(this.myform.value)
    this.catego.save(this.myform.value).subscribe(data=>{
      console.log(data)
      this.route.navigate(['/listacatego'])
      this._snackBar.open('La categoria fue dada de alta', 'cerrar', {
        duration: 2000,
      });
    })
  }

  ngOnInit(): void {
  }

}
