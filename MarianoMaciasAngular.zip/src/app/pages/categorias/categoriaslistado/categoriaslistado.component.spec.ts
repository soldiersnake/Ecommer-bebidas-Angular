import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoriaslistadoComponent } from './categoriaslistado.component';

describe('CategoriaslistadoComponent', () => {
  let component: CategoriaslistadoComponent;
  let fixture: ComponentFixture<CategoriaslistadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategoriaslistadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoriaslistadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
