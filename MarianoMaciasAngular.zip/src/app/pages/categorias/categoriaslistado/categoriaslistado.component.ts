import { Component, OnInit } from '@angular/core';
import { CategoriasService } from 'src/app/services/categorias.service';

@Component({
  selector: 'app-categoriaslistado',
  templateUrl: './categoriaslistado.component.html',
  styleUrls: ['./categoriaslistado.component.css']
})
export class CategoriaslistadoComponent implements OnInit {

  rows:any[]=[]
  page={
    totalElements:0,
    pageNumber:0,
    size:20
  }
  columns=[]
  constructor(private categoriaService:CategoriasService) {
    this.page["pageNumber"] = 0;
    this.page["size"] = 20;
    this.columns=[
      { name: 'Nombre', prop: 'name' }, 
  ]
  }
  setPage(pageInfo){
    this.categoriaService.getCategorias(pageInfo).subscribe(data=>{
      console.log(data)
      this.rows=data["docs"]
      console.log(this.rows)
      this.page["totalElements"] = data["totalDocs"]
      this.page["size"] = data["limit"]
      this.page["pageNumber"] = pageInfo["offset"]
      console.log(this.page)
    })
    }

    eliminar(id){
      console.log(id)
      this.categoriaService.delete(id).subscribe(data=>{
        console.log("eliminar", data)
        this.setPage({ offset: 0});  //vuelvo a llamar a offset para q refresque la tabla
      })
      

  }
  ngOnInit(): void {
      this.setPage({ offset: 0});
  }
}
