import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms';
import { CategoriasService } from 'src/app/services/categorias.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-categoriaseditar',
  templateUrl: './categoriaseditar.component.html',
  styleUrls: ['./categoriaseditar.component.css']
})
export class CategoriaseditarComponent implements OnInit {
  id;
  myform:FormGroup;  //3º luego declaramos la variable de clase myform q responde a formGroup
  categorias=<any>[]

  constructor(private fb:FormBuilder, private catego:CategoriasService, private route:ActivatedRoute) { //2ºinyectamos en el contructor la dependencia de formbuilder alojandola en la variable fb / ingresamos productosServices para poder realizar el POST
    
    this.id = this.route.snapshot.paramMap.get("id")
    this.myform = this.fb.group({ //4º paso delaramos myform es igual a fb.group
    nombre:["",Validators.required],   //5º asignamos estructura de formulario
   })
   this.catego.getByid(this.id).subscribe(data=>[
     this.myform = this.fb.group({
      nombre:[data["nombre"],Validators.required],
     })
   ])
  }
  save(){ // generamos el metodo save para guardar el formulario q lo sitamos en el .html con (ngSubmit)
    console.log(this.myform.value)
    this.catego.update(this.id,this.myform.value).subscribe(data=>{
      console.log(data)
    })
  }

  ngOnInit(): void {
  }

}
