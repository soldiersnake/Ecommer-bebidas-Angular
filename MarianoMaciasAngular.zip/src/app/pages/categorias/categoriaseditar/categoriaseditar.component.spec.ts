import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoriaseditarComponent } from './categoriaseditar.component';

describe('CategoriaseditarComponent', () => {
  let component: CategoriaseditarComponent;
  let fixture: ComponentFixture<CategoriaseditarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategoriaseditarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoriaseditarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
