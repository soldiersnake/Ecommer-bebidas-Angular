import { Component, OnInit } from '@angular/core';
import { ProductosService } from '../../services/productos.service';

@Component({
  selector: 'app-listadoprod',
  templateUrl: './listadoprod.component.html',
  styleUrls: ['./listadoprod.component.css']
})
export class ListadoprodComponent implements OnInit {

  rows:any[]=[]
  page={
    totalElements:0,
    pageNumber:0,
    size:20
  }
  columns=[]
  constructor(private productService:ProductosService) {
    this.page["pageNumber"] = 0;
    this.page["size"] = 20;
    this.columns=[
    { name: 'Nombre de producto', prop: 'name' }, 
    { name: 'Marca', prop: 'marca' }, 
    { name: 'Precio', prop: 'precio' }
  ]
  }
  setPage(pageInfo){
    this.productService.getProductos(pageInfo).subscribe(data=>{
      console.log(data)
      this.rows=data["docs"]
      console.log(this.rows)
      this.page["totalElements"] = data["totalDocs"]
      this.page["size"] = data["limit"]
      this.page["pageNumber"] = pageInfo["offset"]
      console.log(this.page)
    })
    }

    eliminar(id){
      console.log(id)
      this.productService.delete(id).subscribe(data=>{
        console.log("eliminar", data)
        this.setPage({ offset: 0});  //vuelvo a llamar a offset para q refresque la tabla
      })
      

  }
  ngOnInit(): void {
      this.setPage({ offset: 0});
  }
}
