import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListadoprodComponent } from './listadoprod.component';

describe('ListadoprodComponent', () => {
  let component: ListadoprodComponent;
  let fixture: ComponentFixture<ListadoprodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListadoprodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListadoprodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
