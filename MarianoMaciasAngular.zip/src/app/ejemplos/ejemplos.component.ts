import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ejemplos',
  templateUrl: './ejemplos.component.html',
  styleUrls: ['./ejemplos.component.css']
})
export class EjemplosComponent implements OnInit {

  productos=[];  //en productos y clientes, declaro la variable y luego la inicio en el contructor
  clientes=[];
  proveedores=[  //aca declaro e inicio la variable
    {
      nombre:"Coca-cola",
    },
    {
      nombre:"Danone",
    },
    {
      nombre:"Bodegas Lopez",
    },
  ];


  title = 'proyectofinalang';
  modificado=false;
  suma=0;
  numero1;
  numero2;
  class_resultado="";
  productoss=[{
    "id":"",
    "name":"productos1"
  },
  {
    "id":"",
    "name":"productos2"
  },
  {
    "id":"",
    "name":"productos3"
  },
  
  


];
  cambiarTitle(){
    this.title="NUEVO TITULO";
    this.modificado=true;
  }
  sumar(){
    this.suma=parseInt(this.numero1) + this.numero2 *1;
    if(this.suma>0){
      this.class_resultado="positivo","resultado"
    }
    else{
      this.class_resultado="negativo","resultado"
    }
  }


  constructor() {

    this.productos=[{   //aca en el constructor estoy iniciando la variable antes declarada
      "id":"1",
      "nombre":"Levite",
    },
    {
      "id":"2",
      "nombre":"Jack Daniels",
    },{
      "id":"3",
      "nombre":"Vino Lopez",
    },
  ]
  
  this.clientes=[{
    "edad":"23",
    "nombre":"ana",
  },
  {
    "edad":"20",
    "nombre":"daniel",
  },{
    "edad":"30",
    "nombre":"Venicio",
  },
]


  }

  ngOnInit(): void {
  }

}
