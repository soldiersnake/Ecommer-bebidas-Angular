import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AutenticacionService } from './services/autenticacion.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private auth:AutenticacionService){} //el contructor puede estar o no, es para generar el return del servicio, q es seria mismo q el codigo if
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
      /*let token = localStorage.getItem("token");  //este metodo podria servi, si no hago la creacion del contructur y sitando al servicio de autenticacion para genear el return
      if(token){
        return true
      }else{
        return false;
      }*/
      return this.auth.isAuthenticate();
  }
  
}
