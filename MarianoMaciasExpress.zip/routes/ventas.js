var express = require('express');
var router = express.Router();
var ventascontrollers = require("../controllers/ventascontrollers"); //la direccion de controller


router.get('/', ventascontrollers.getall);
router.post('/', ventascontrollers.cargarVenta);


module.exports = router;
