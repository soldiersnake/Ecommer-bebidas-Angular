var express = require('express');
var router = express.Router();

//3- Require del controlador
var categoriasController = require("../controllers/categoriasController")

/* GET home page. */
router.get('/', categoriasController.getall);
router.get('/combo/', categoriasController.getAllSinPaginado);
router.get('/:id', categoriasController.getByid);
router.post('/', categoriasController.postCategorias); //agregue para cargar categorias
router.put('/:id', categoriasController.update);
router.delete('/:id', categoriasController.delete);


module.exports = router;