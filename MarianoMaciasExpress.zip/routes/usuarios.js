var express = require('express');
var router = express.Router();
var usuarioscontrollers = require("../controllers/usuarioscontrollers"); //la direccion de controller


/* Consulto devuelve info de usuario */
router.get('/', usuarioscontrollers.getall);
router.get('/:id', usuarioscontrollers.getByid);


router.post('/registro', usuarioscontrollers.cargarUsuarios);  // Creo usuario
router.post('/login', usuarioscontrollers.login); //El usuario se logea
/* inserto usuario 
router.put('/', usuarioscontrollers.insertarUsuarios);

elimino usuario 
router.delete('/', usuarioscontrollers.eliminarUsuarios);
*/

module.exports = router;
