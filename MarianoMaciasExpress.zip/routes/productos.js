var express = require('express');
var router = express.Router();

var productoscontrollers = require("../controllers/productoscontrollers"); //la direccion de controller

var multer = require('multer'); //FIleupload
var DIR = './public/images';    //FIleupload
var upload = multer({dest:DIR}).single('photo'); //FIleupload

/* Consulto por query, todo lo q halla detras del ? en la consulta */
//aca presentamos las consultas q realizamos en productoscontrollers.js sobre productos en este caso
router.get('/', productoscontrollers.getall);
router.get('/:id', productoscontrollers.getByid);
router.get('/destacados', productoscontrollers.getBydestacados);
router.get('/categoria', productoscontrollers.getByCategoria);
router.post('/', productoscontrollers.cargarProducto);
router.put('/:id', productoscontrollers.actualizarProducto);
router.delete('/:id', productoscontrollers.eliminar);

//ruta de upLoad
router.post('/upload', productoscontrollers.upload);



module.exports = router;
