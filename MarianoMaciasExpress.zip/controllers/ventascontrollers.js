var ventasmodel = require("../models/ventasmodel");
var productosmodel = require("../models/productosmodel"); //hacemos el REQUIRE de productosmodel para traer la data de la coleccion de la misma



module.exports ={
    getall: async function(req, res, next){
        let productos = await productosModel.find({})
        let productosCategoria = await categoriasmodel.populate(productos,{path:'categorias'}) //en esta linea armo el POPULATE
        console.log(productos)
        res.status(200).json(productosCategoria)
    },
    //metodo de tipo post (por postman raw/json)
    cargarVenta: async function(req,res, next){
        console.log(req.body.usuarioToken)

        let products_query=[]        //aca armamos la array para el changuito
        req.body.products.map(products=>{  //aplicamos el .map para iterarlo
            products_query.push(products.product_id) //hacemos .push de de los productos_id para tener todos los productos del carrito

        })
        console.log(products_query)

        let productos = await productosmodel.find({}) // se crea el find
        .select(['name','precio']) //este .select permite seleccionar compos de decumentos
        .where('_id').in(products_query).populate('categoria')  //y el .where trae solo los productos del array
        
        //console.log(productos)

        let total=0;  //pongo la variable en 0 para hacer la suma de productos
        let records = productos.map(products=>{   //con el map recorremos respuesta de mongoose
            total+=products['precio']  //sumo los precios de los productos
            return({
                product_id:products["_id"],
                name:products['name'],
                precio:products['precio']
            })
        })
        //console.log(records)
        console.log("okey")
        console.log(req.body.usuarioToken)

        let ventas = new ventasmodel({
            user:req.body.usuarioToken.usuarioLogin._id,  // relacionamos la SUBCATEGORIA usuario a la venta
            total: total, //aca iria la suma de la variable TOTAL
            products: records  //products fue creado en models para generar la SUBCATEGORIA
                
            
            
        })
        let data = await ventas.save(); //generamos el save q guarda los datos en la BD
        res.status(201).json({"status":"okey","data":data})
    },


}
