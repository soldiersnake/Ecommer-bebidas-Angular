var usuariosModel = require("../models/usuariosmodel")
const bcrypt = require('bcrypt');  //requerimos bcrypt para encriptar el password o cualquier otro dato
const jwt = require('jsonwebtoken'); //aca hacemos el require del TOKEN
const { token } = require("morgan");


module.exports ={
    getall: async function(req, res, next){
        let usuarios = await usuariosModel.find({})
        console.log(usuarios)
        res.status(200).json(usuarios)
    },
    getByid: async function(req,res,next){
        console.log(req.params.id)
        let usuarios = await usuariosModel.findById(req.params.id);
        res.status(200).json(usuarios)
    },

    //metodo de tipo post (por postman raw/json)
    cargarUsuarios: async function(req,res, next){
        try{  //aplicamos un tray n' chach, para q no pinche la app, x si en este caso en la BD se encuentra un usuario repetido
        let usuarios = new usuariosModel({
            nombre: req.body.nombre,
            apellido: req.body.apellido,
            email:req.body.email,
            usuario: req.body.usuario,
            password: req.body.password
        })
        let data = await usuarios.save(); //generamos el save q guarda los datos en la BD
        res.status(201).json("registro exitoso")  //estoy devolviendo mensaje de carga exitosa
    }catch(e){
        console.log(e)
        res.status(201).json("Usuario ya existente")
        next(e)
    }
    },

    login: async function(req, res, next){  //aca solicitamos el login a la BD
        //consulta por usuario
        let usuarioLogin = await usuariosModel.findOne({usuario:req.body.usuario}) //utilizamos findOne para corraborar q el usuario q cargan sea igual de la BD
        if(usuarioLogin){
            //valido el password
            if(bcrypt.compareSync(req.body.password,usuarioLogin.password)){ //compareSync compara el dato plano y el encriptado para determianr si son iguales
                //password valido, genero token
                const token = jwt.sign({usuarioLogin:usuarioLogin},req.app.get('secretKey'),{expiresIn:'3h'}) //aca creamos el token solicitando secretKet de .app ,'expiresIn' es para determianr la duracion del TOKEN
                res.status(201).json({token:token})
            }else{
                //password invalido
                res.json({message:"password incorrecto",data:null})
            }
        }else{
            //arrojamos error
            res.json({message:"usuario no existe",data:null})
        }

        res.status(201).json(usuarioLogin)
    }

}
