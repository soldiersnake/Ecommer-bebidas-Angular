//4- Require del modulo
var categoriasmodel = require("../models/categoriasmodel")

module.exports = {

    getall: async function(req, res, next){
        let categorias = await categoriasmodel.paginate({},{ //aplicamos el paginado y las opciones del mismo
            limit:10,
            sort:{name:1},
            page:(req.query.page?req.query.page:1)
        })
        console.log(categorias)
        res.status(200).json(categorias)
    },

    getAllSinPaginado: async function(req, res, next) {
        let categorias = await categoriasmodel.find({})
        res.status(200).json(categorias)
    },

      getByid: async function(req,res,next){
        console.log(req.params.id)
        let categorias = await categoriasmodel.findById(req.params.id);
        console.log(categorias)
        res.status(200).json(categorias)
    },

    postCategorias: async function(req,res, next){   //agregue para cargar categorias pero algo rompe
        let categorias = new categoriasmodel({
            nombre: req.body.nombre,
        })
        let data = await categorias.save(); //generamos el save q guarda los datos en la BD
        res.status(201).json({"status":"okey","data":data})
      },
      
    update: async function(req, res, next) {
        let data = await categoriasmodel.update({ _id: req.params.id}, req.body, { multi: false })
        res.status(201).json({"stauts":"ok","data":data})
    },

    delete: async function(req, res, next) {
        let data = await categoriasmodel.deleteOne({_id:req.params.id});
        res.status(201).json({"stauts":"ok","data":data})
    }
}

