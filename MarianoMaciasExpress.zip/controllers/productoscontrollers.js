//aca se maneja la logica de las consultas
var productosModel = require("../models/productosmodel");
var categoriasmodel = require("../models/categoriasmodel");
var multer = require('multer'); //FIleupload
var DIR = './public/images';    //FIleupload
var upload = multer({dest:DIR}).single('photo'); //FIleupload

module.exports ={
    getall: async function(req, res, next){
        let productos = await productosModel.paginate({},{ //aplicamos el paginado y las opciones del mismo
            populate:'categorias',
            limit:16,
            sort:{name:1},
            page:(req.query.page?req.query.page:1)
        })
        console.log(productos)
        res.status(200).json(productos)
    },

    getByCategoria: async function(req, res, next) {
  
        let productos = await productosModel.paginate({categorias:req.params.id},{
            populate:'categorias',
            limit:2,
            sort:{name:1},
            page:(req.query.page?req.query.page:1)
        })
        console.log(productos)
        res.status(200).json(productos)
      },


    getBydestacados: async function(req, res, next){
        console.log(req.params.destacados)
        let productos = await productosModel.find({'destacados':1});
        console.log(productos)
        res.status(200).json(productos)
    },


    getByid: async function(req,res,next){
        console.log(req.params.id)
        let productos = await productosModel.findById(req.params.id);
        console.log(productos)
        res.status(200).json(productos)
    },

    //metodo de tipo post (por postman raw/json)
    cargarProducto: async function(req,res, next){   //estos mismos campos tienen q ser los mismo, declarados en el models
        let productos = new productosModel({
            name: req.body.name,
            precio: req.body.precio,
            marca: req.body.marca,
            descripcion:req.body.descripcion, //agregue
            sku: req.body.sku,
            cantidad: req.body.cantidad,
            categorias: req.body.categorias,
            imagen: req.body.imagen
        })
        let data = await productos.save(); //generamos el save q guarda los datos en la BD
        res.status(201).json({"status":"okey","data":data})
    },

    actualizarProducto: async function(req,res, next){
        let data = await productosModel.findByIdAndUpdate(req.params.id,{$set:req.body})    //findbyidandupdate deja actualizar mas de uno
        res.status(201).json({"status":"okey","data":data})
    },

    eliminar: async function(req, res, next) {
        let data = await productosModel.deleteOne({_id:req.params.id});
        res.status(201).json({"stauts":"ok","data":data})
    },

    upload: async function(req, res, next){
        try{
        var path = '';
        upload(req, res, function (err){
            
            if(err){

                console.log(err);
                next()
            }

            path = req.file.path;
            res.status(201).json({status:"succes", message: "imagen cargada exitosamente", data: req.file});
        });
    }catch(e){
    }

}
}
