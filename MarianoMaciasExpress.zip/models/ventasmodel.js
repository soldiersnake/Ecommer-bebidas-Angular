const mongoose = require("../bin/mongodb");
const Schema = mongoose.Schema;

//aca creamos el esquema de la base de datos para mongo, el modelo y su logica de datos

var productSchema = new Schema({
    product_id: {type:Schema.ObjectId, ref:"productos"},  //aca esta la relacion con la COLECCION productos de la BD
    name : {            //esto seria schema types, especifica como debe ser el schema
        type: String,
        uppercase : true,
        required: true
    },
    precio : {
        type: Number,
        required: true,
        min: 0    //aca establezco q el monto del producto no pueda ser menos a CERO
    },
});

const MainSchema = new Schema({
    products:[productSchema],    //aca se creo EL SUBDOCUMENTO con un Schema [SE USAN LOS CORCHETES PARA Q SEA ARRAY en este caso un carrito de compra]
    fecha : {            //esto seria schema types, especifica como debe ser el schema
        type: Date,
        required: true,
        default:Date.now
    },
    total : {
        type: Number,
        required: true,
        min: 0    //aca establezco q el monto del producto no pueda ser menos a CERO
    },
    user:{type:Schema.ObjectId,ref:"usuarios"} //agregamos al SUBDOCUMENTO la relacion usuarios a la venta
});

mongoose.model('ventas', MainSchema)



// esta es la coneccion a la base de datos, dnd se hace la exportacion
module.exports = mongoose.model('ventas',MainSchema) //productos es el nombre de la coleccion de la base de datos
