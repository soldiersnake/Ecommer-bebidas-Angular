const mongoose = require("../bin/mongodb");
const bcrypt = require('bcrypt');  //requerimos bcrypt para encriptar el password o cualquier otro dato
const Schema = mongoose.Schema;


//creacion de schema (el modelo define la estructura de los documentos)
const MainSchema = new Schema({
    nombre : {
        type: String,
        required: [true, 'el campo nombre es obligatorio']   //lo hago obligatorio y hago un array[] para mandar mensaje por error
    },
    apellido : {
        type: String,
        required: [true,'el campo apellido es obligatorio']
    },
    email : {           //aplico schema types, q espifica como deje ver el schema
        type: String,
        unique: true
    },
    usuario : {           //aplico schema types, q espifica como deje ver el schema
        type: String,
        unique: true
    },
    password : {
        type: String,
        minlength : 6
    }
});

MainSchema.pre('save', function(next){  //aca encriptamos el password utilizando bcrypt
    this.password = bcrypt.hashSync(this.password,10); //hashSync recibe 'this.password' y lo encripta
    next();   // este next continua la ejecucion
})

mongoose.model('usuarios', MainSchema)

module.exports = mongoose.model('usuarios',MainSchema) //usuarios es el nombre de la coleccion de la base de datos

