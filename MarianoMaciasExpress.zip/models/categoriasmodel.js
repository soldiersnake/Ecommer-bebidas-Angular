const mongoose = require("../bin/mongodb");
const Schema = mongoose.Schema;


const MainSchema = new Schema({
    nombre : {   //esto seria schema "types", especifica como debe ser el schema
        type: String,
        uppercase : true,
        trim:true,
        required: true
    }
})

//generamos el modelo  y entre('va el nombre de la coleccion de la BD')
mongoose.model('categorias', MainSchema);
MainSchema.plugin(mongoose.mongoosePaginate);//tenemos q colocar el paginate para q funcione, en cada dependencia

// esta es la coneccion a la base de datos, dnd se hace la exportacion
module.exports = mongoose.model('categorias',MainSchema) //categorias es el nombre de la coleccion de la base de datos
