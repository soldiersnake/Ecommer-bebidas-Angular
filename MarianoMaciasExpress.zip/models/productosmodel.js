//los models son los que tienen relacion con la base de datos, respondiendo a las consultas hechas en la logica de controllers
const mongoose = require("../bin/mongodb");
const Schema = mongoose.Schema;

var imgSchema = new Schema({
    destination: "string",
    encoding: "string",
    fieldname: "string",
    filename: "string",
    mimetype: "string",
    originalname: "string",
    path: "string",
    size: "string"
    });


//aca creamos el esquema de la base de datos para mongo, el modelo y su logica de datos

const MainSchema = new Schema({
    name : {            //esto seria schema types, especifica como debe ser el schema
        type: String,
        uppercase : true,
        required: true
    },
    precio : {
        type: Number,
        min:0,
        required: true,
        min: 0    //aca establezco q el monto del producto no pueda ser menos a CERO
    },
    marca :{
        type: String,
        required: true,
    },
    descripcion :{ //agregue
        type: String,
        required: true,
    },
    sku: {
        type: String,
        unique: true,
        required: [true,'el campo SKU es obligatorio']   //lo hago obligatorio
    },
    cantidad: Number,
    categorias:[{ type:Schema.ObjectId,ref:"categorias"}],//en el seccion categoria genero un POPULATE, a la coleccion "categorias"
    images:[imgSchema],
});

MainSchema.set('toJSON',{getters:true,virtuals:true}); //los virtuas son los campos q no existe en el documento
//generamos el modelo  y entre('va el nombre de la coleccion de la BD')

//generamos el paginate
MainSchema.plugin(mongoose.mongoosePaginate);

// esta es la coneccion a la base de datos, dnd se hace la exportacion
module.exports = mongoose.model('productos',MainSchema) //productos es el nombre de la coleccion de la base de datos
